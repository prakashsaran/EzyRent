export const GUEST_TYPE = 'account_guest_type';
export const ADMIN_TYPE = 'account_admin_type';
export const TENANT_TYPE = 'account_tenant_type';
export const LANDLORD_TYPE = 'account_landloard_type';
export const LANDLORD_TENANT_TYPE = 'account_landloard_tenant_type';
