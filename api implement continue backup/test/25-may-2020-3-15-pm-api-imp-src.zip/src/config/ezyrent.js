export const ezyrentOptions = {
  url: 'https://api.ezyrent.net/ezyrentapi',
  authentication: {
    integration: {
      access_token: null,
    },
  },
};

