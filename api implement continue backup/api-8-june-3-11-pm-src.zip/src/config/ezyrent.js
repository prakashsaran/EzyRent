export const ezyrentOptions = {
  url: 'https://api.ezyrent.net/ezyrentapi',
  media_path: 'https://ezyrentbucket.s3.ap-south-1.amazonaws.com/ezimage/',
  authentication: {
    integration: {
      access_token: null,
    },
  },
};

