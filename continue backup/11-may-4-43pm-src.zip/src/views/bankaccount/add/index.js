import React, { Component } from "react";
import { StyleSheet,StatusBar,ScrollView,TouchableOpacity, View,Image, Text, ImageBackground,TextInput } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import RNPickerSelect from 'react-native-picker-select';
import NavigationService from '../../../navigation/NavigationService';
import { ThemeContext, theme } from '../../../theme';
import styles from './style';
import {
  NAVIGATION_MORE_MY_BANKACCOUNT_VIEW_PATH,
} from '../../../navigation/routes';

class AddBankAccount extends React.Component {
  static contextType = ThemeContext;
  constructor(props){
    super();
    this.state ={
      nameofBank:undefined,
      accountNumber:undefined,
      crmAcNumber:undefined,
      acHolderName:undefined,
      typeOfAc:undefined,
      ifscCode:undefined,
      additionalDetails:undefined,
    }
    StatusBar.setBarStyle("light-content");
    this._nameofBankEntry = undefined;
    this._accountNumberEntry = undefined;
    this._crmAcNumberEntry = undefined;
    this._acHolderNameEntry = undefined;
    this._typeOfAcEntry = undefined;
    this._ifscCodeEntry = undefined;
    this._additionalDetailsEntry = undefined;
  }
  
  submitForm(){
    NavigationService.navigate(NAVIGATION_MORE_MY_BANKACCOUNT_VIEW_PATH);
  }
  renderHeader(){
    return(
      <View style={styles.titleWrapper}>
        <TouchableOpacity onPress={()=>NavigationService.goBack()} style={styles.backscreen}>
          <Image style={styles.backscreen} resizeMode={'stretch'} source={require('../../../assets/images/arrow_left.png')}></Image>
        </TouchableOpacity>
        <Text style={theme.typography.myDashBoard}>Add New Bank Account</Text>
      </View>
    )
  }
  render(){
    const {nameofBank,accountNumber,crmAcNumber,acHolderName,typeOfAc,ifscCode,additionalDetails} = this.state
    const theme = this.context;
      return (
        <ImageBackground style={{width:'100%',height:'100%'}} resizeMode={'cover'} source={require('../../../assets/images/dashboard_bg.png')}>
          <SafeAreaView style={styles.container}> 
            {this.renderHeader()}
              <ScrollView 
              showsVerticalScrollIndicator={false}
              >                  
                <View style={styles.rectWrapp}>
                  <View style={theme.typography.rectView}>
                    
                          <Text style={styles.columntitle(theme)}>ADD YOUR BANK ACCOUNT DETAILS</Text>

                          <View style={styles.fieldWrapp}>
                             <Text style={styles.tooltip(theme)}>Name of Bank *</Text>
                              <TextInput ref={(ref) => this._nameofBankEntry = ref} onChangeText={(nameofBank) =>{this.setState({nameofBank})}} autoCorrect={false} style={styles.textInputStyle(theme)} value={nameofBank} placeholder={'Name Of Bank Account'}/>
                          </View>

                          <View style={styles.fieldWrapp}>
                             <Text style={styles.tooltip(theme)}>Account Number *</Text>
                              <TextInput secureTextEntry={true} ref={(ref) => this._accountNumberEntry = ref} onChangeText={(accountNumber) =>{this.setState({accountNumber})}} autoCorrect={false} style={styles.textInputStyle(theme)} value={accountNumber} placeholder={'Account Number'}/>
                          </View>

                          <View style={styles.fieldWrapp}>
                             <Text style={styles.tooltip(theme)}>Confirm Account Number *</Text>
                              <TextInput ref={(ref) => this._crmAcNumberEntry = ref} onChangeText={(crmAcNumber) =>{this.setState({crmAcNumber})}} autoCorrect={false} style={styles.textInputStyle(theme)} value={crmAcNumber} placeholder={'Account Number'}/>
                          </View>

                          <View style={styles.fieldWrapp}>
                             <Text style={styles.tooltip(theme)}>Account Holder Name *</Text>
                              <TextInput ref={(ref) => this._acHolderNameEntry = ref} onChangeText={(acHolderName) =>{this.setState({acHolderName})}} autoCorrect={false} style={styles.textInputStyle(theme)} value={acHolderName} placeholder={'Account Holder Name'}/>
                          </View>

                          <View style={styles.fieldWrapp} ref={(ref) => this._typeOfAcEntry = ref} >
                             <RNPickerSelect
                                  placeholder={{
                                    label: 'Type of Account',
                                    value: null,
                                    color: '#000000',
                                  }}
                                  style={pickerSelectStyles}
                                  onValueChange={(typeOfAc) => this.setState({typeOfAc})}
                                  items={[
                                      { label: 'Current Account', value: '1' },
                                      { label: 'Savings Account', value: '1' },
                                      { label: 'Recurring Deposit Account', value: '3' },
                                      { label: 'Fixed Deposit Account', value: '4' },
                                  ]}
                                  Icon={() => {
                                    return (
                                      <Image style={{width:14,height:15}} source={require('../../../assets/images/arrowdown_picker.png')}/>
                                    );
                                  }}
                                />
                          </View>


                          <View style={styles.fieldWrapp}>
                              <TextInput ref={(ref) => this._ifscCodeEntry = ref} onChangeText={(ifscCode) =>{this.setState({ifscCode})}} autoCorrect={false} style={styles.textInputStyleSec(theme)} value={ifscCode} placeholder={'IFSC Code/Sort Code'}/>
                          </View>


                          <View style={styles.fieldWrapp}>
                              <TextInput ref={(ref) => this._additionalDetailsEntry = ref} onChangeText={(additionalDetails) =>{this.setState({additionalDetails})}} autoCorrect={false} style={styles.textInputStyleSec(theme)} value={additionalDetails} placeholder={'Additional Details'}/>
                          </View>
                          <View style={styles.spacing}></View>


                  </View>
                </View>
              </ScrollView>
              {this.reanderButton()}
          </SafeAreaView>
        </ImageBackground>
      );
  }
  reanderButton(){
    return (
      <TouchableOpacity onPress={()=>this.submitForm()} style={styles.addBtncontainer(theme)}>
        <Text style={styles.addBtncaption(theme)}>ADD</Text>
      </TouchableOpacity>
    );
  }

}
export default AddBankAccount;
const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 18,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderColor: theme.colors.descriptionColor,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
  },
  inputAndroid: {
    fontSize: 18,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderBottomWidth: 0.5,
    borderColor: theme.colors.descriptionColor,
    borderRadius: 8,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
  },
  iconContainer: {
    top: 20,
    right: 0,
  },
});