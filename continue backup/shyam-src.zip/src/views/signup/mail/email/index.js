import React, { Component,useContext ,useState,useEffect} from "react";
import {View, Image, Text,ScrollView,SafeAreaView,TouchableOpacity,TextInput,KeyboardAvoidingView,Platform } from "react-native";
import styles from './style';
import { ThemeContext } from '../../../../theme';
import {NAVIGATION_SIGN_UP_MOBILE_OTP_PATH} from '../../../../navigation/routes';
import NavigationService from '../../../../navigation/NavigationService';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { signupMail,isValidEmail } from '../../../../actions';

function SignUpMail(props) {
  const [emailaddress, setEmailAddress] = useState('');
  const [enablebtn, setEnableButton] = useState(false);
  let keyboardBehavior = "padding";

  const theme = useContext(ThemeContext);
  const onChangeEmailAdress = (email) =>{
    setEmailAddress(email);
    //console.log("current mail status",isValidEmail(email))
    setEnableButton(isValidEmail(email));
  }
  const submit = () =>{
    props.signupMail(emailaddress);
  }
  useEffect(() => {
    // ComponentDidMount
    if (Platform.OS == 'android') {
        keyboardBehavior = 'height'
    }

  }, []);

  return (
    <SafeAreaView style={styles.container(theme)}>
      <KeyboardAvoidingView behavior={keyboardBehavior} >
            <ScrollView>

              <Image
                source={require("../../../../assets/images/ezyrent_logo.png")}
                resizeMode="contain"
                style={styles.image}
              ></Image>

              <Text style={styles.stepTitle(theme)}>Create Your Account</Text>

              <Text style={styles.signstep(theme)}>STEP 3 OF 5</Text>

              <Text style={styles.stepmessage(theme)}>Please enter your email address</Text>

              <Text style={styles.mobelTitle(theme)}>EMAIL ID</Text>

              <View style={styles.mobileWrapper(theme)}>
                <TextInput 
                  placeholder="example@domain.com"
                  keyboardType={'email-address'}
                  style={styles.mobileInput(theme)}
                  value={emailaddress}
                  autoCorrect={false}
                  autoCapitalize={false}
                  allowFontScaling={false}
                  onChangeText={(email) =>onChangeEmailAdress(email)}
                />
              </View>
              <TouchableOpacity disabled={!enablebtn} style={enablebtn?styles.btnProceed(theme):styles.btnProceedDisabled(theme)}  onPress={()=>{submit()}}>
                <Text style={styles.caption(theme)}>PROCEED</Text>
              </TouchableOpacity>

              <Text style={styles.copyright(theme)}>Copyright @ EzyRent 2020. All Rights Reserved</Text>

            </ScrollView>
          </KeyboardAvoidingView>
        <Image
          source={require("../../../../assets/images/ezyrent-footer-icon.png")}
          resizeMode={'cover'}
          style={styles.footerImage}
        ></Image>

    </SafeAreaView>
  );
}

const mapStateToProps = ({ signup }) => {
  const { error, success, loading } = signup;

  return { error, success, loading };
};

SignUpMail.propTypes = {
  loading: PropTypes.bool,
  error: PropTypes.oneOfType(PropTypes.string, null),
  success: PropTypes.oneOfType(PropTypes.string, null),
  signupMail: PropTypes.func.isRequired,
  isValidEmail: PropTypes.func.isRequired,
};

SignUpMail.defaultProps = {
  error: null,
  success: null,
  loading: false,
};

export default connect(mapStateToProps, { signupMail })(SignUpMail);
