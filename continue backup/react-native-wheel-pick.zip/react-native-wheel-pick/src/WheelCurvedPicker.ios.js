import React from 'react';
import { PickerIOS } from 'react-native';

export default PickerIOS;
