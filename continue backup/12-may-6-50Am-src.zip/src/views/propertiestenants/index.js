import React, { Component } from "react";
import { StyleSheet,StatusBar,ScrollView,TouchableOpacity, View,Image, Text, ImageBackground, TextInput } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { FloatingAction } from "react-native-floating-action";
import NavigationService from '../../navigation/NavigationService';
import SampleData from '../../config/sample-data';
import { ThemeContext, theme } from '../../theme';
import styles from './style';
import {
  NAVIGATION_ADD_PROPERTIES_TENANTS_VIEW_PATH,
  NAVIGATION_DETAIL_PROPERTIES_TENANTS_VIEW_PATH,
  NAVIGATION_DETAIL_PROPERTIES_LANDLORD_VIEW_PATH,
  NAVIGATION_MORE_TRANSACTION_SUCCESS_VIEW_PATH,
} from '../../navigation/routes';


class PropertiesTenants extends React.Component {
  static contextType = ThemeContext;
  constructor(props){
    super();
    this.state={
      visibleSearch:false,
      payingRent:[],
      collectingRent:[],
      activeTab:1,
      searchQuery:null,
    }
    StatusBar.setBarStyle('dark-content');
  }
  componentDidMount(){
    const properties = SampleData.getPropeties() || [];
    this.setState({payingRent:properties,collectingRent:properties})
  }

  addPropertyTenant(){
    NavigationService.navigate(NAVIGATION_ADD_PROPERTIES_TENANTS_VIEW_PATH);
  }

  getMoneyFormat(amount, decimalCount = 2, decimal = ".", thousands = ",") {
    try {
      decimalCount = Math.abs(decimalCount);
      decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

      const negativeSign = amount < 0 ? "-" : "";

      let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
      let j = (i.length > 3) ? i.length % 3 : 0;

      return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
    } catch (e) {
      console.log(e)
    }
  };
  ProPertyDetailTenant(){
    NavigationService.navigate(NAVIGATION_DETAIL_PROPERTIES_TENANTS_VIEW_PATH);
  }
  ProPertyDetailLandlord(){
    NavigationService.navigate(NAVIGATION_DETAIL_PROPERTIES_LANDLORD_VIEW_PATH);
  }
  /* *
  * name getDateFormat
  * @params String
  * @return String
  */
  getDateFormat(str){
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    const unixTimeZero = Date.parse(str);
    const date = new Date(unixTimeZero);
    const dt = date.getDate();
    const fmt = monthNames[date.getMonth()]
    const fly = date.getFullYear();
    const fdt = dt < 10 ? '0' + dt : '' + dt;
     return fdt+ ' '+fmt +' '+fly;
  }
  PayRent(){
    NavigationService.navigate(NAVIGATION_MORE_TRANSACTION_SUCCESS_VIEW_PATH)
  }
  renderHeader(){
    const {visibleSearch,searchQuery} = this.state
    return(
      <View style={styles.headWrapp}>
        <View style={styles.headcontainer}>
          <View style={styles.textWrapper}>
            <Text numberOfLines={1} style={theme.typography.title}>
            Properties/Tenants
            </Text>
          </View>
          <View style={styles.textWrapperFiller}></View>
          <View style={styles.rightIconsWrapper}>
            <TouchableOpacity style={styles.iconButton} onPress={()=>this.setState({visibleSearch:!visibleSearch})}>
              <Image style={styles.headerIcon} resizeMode={'contain'} source={require('../../assets/images/search.png')}/>
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton2}>
            <Image style={styles.headerIcon} resizeMode={'contain'} source={require('../../assets/images/filter.png')}/>
            </TouchableOpacity>
          </View>
        </View>
        {visibleSearch && <View style={styles.searchWrap}>
            <View style={styles.inputStyleStack(theme)}>
              <TextInput onChangeText={(searchQuery)=>this.setState({searchQuery})} placeholder="Search" value={searchQuery} style={styles.searchinputStyle}></TextInput>
            </View>
        </View>}
      </View>
    )
  }
  render(){
    const theme = this.context;
    const {activeTab} = this.state
      return (
          <SafeAreaView style={styles.container(theme)}>
            {this.renderHeader()}
                <View style={styles.tabWrapp}>
                  <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                      <View style={styles.tabsrows}>
                        <View style={activeTab==1?styles.Activetabitem(theme):styles.inActivetabitem(theme)}>
                          <TouchableOpacity onPress={()=>this.setState({activeTab:1})} style={styles.tabaction}>
                            <Text style={activeTab==1?styles.Activetabtitle(theme):styles.inActivetabtitle(theme)}>I am Paying Rent</Text>
                          </TouchableOpacity>
                        </View>
                        <View style={activeTab==2?styles.Activetabitem(theme):styles.inActivetabitem(theme)}>
                          <TouchableOpacity onPress={()=>this.setState({activeTab:2})} style={styles.tabaction}>
                            <Text style={activeTab==2?styles.Activetabtitle(theme):styles.inActivetabtitle(theme)}>I am Collecting Rent</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </ScrollView>
                </View>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  >
                {this.renderProperties()}
              </ScrollView>
              <FloatingAction animated={activeTab==2?false:true} onPressMain={()=>this.addPropertyTenant()} showBackground={false} visible={activeTab==2?true:false} color={theme.colors.primary} position={'right'}/>

          </SafeAreaView>
      );
  }

  renderProperties(){
    const {activeTab} = this.state
    switch(activeTab){
      case 1:
        return this.renderPayingPropertiest();
      case 2:
        return this.renderCollectingPropertiest();
      default:
        return this.renderPayingPropertiest();
    }
  }

  renderPayingPropertiest(){
    return(
      <View style={styles.properties(theme)}>
        {this.renderPayingItems()}
      </View>
    )
  }

  renderPayingItems(){
    const {payingRent} = this.state

    return payingRent.map((item,inx)=>{
      return (
        <View key={inx} style={styles.loopitem}>
          <ImageBackground imageStyle={styles.loopitembg} style={styles.loopitembg} resizeMode={'cover'} source={this.fasterImageRender(item)}>
            <ImageBackground imageStyle={styles.loopitembgIn} style={styles.loopitembgIn} resizeMode={'stretch'} source={require('../../assets/images/properties_item_bg.png')}>
               <Text style={styles.itemName(theme)}>{item.name}</Text>
               {item.process !="due" && <TouchableOpacity onPress={()=>this.ProPertyDetailTenant()} style={styles.nextscreen(theme)}><Image style={styles.arrow_right} source={require('../../assets/images/arrow_right.png')}></Image></TouchableOpacity>}
               <View style={styles.propertygnInfo}>
                  <View style={styles.propInforowleft}>
                    {item.process=="due"?
                      <Image style={styles.due_label} source={require("../../assets/images/due_label.png")}></Image>
                    :null}
                  </View>
                  <View style={styles.propInforowright}>
                    <View style={styles.propInfoAttrb}>
                      <Image style={styles.map_icon} resizeMode={'contain'} source={require('../../assets/images/map_ellipse.png')}></Image>
                      <Text style={styles.propItemattrLocation(theme)}>{item.location}</Text>
                    </View>
                    <View style={styles.propInfoAttrb}>
                      <Image style={{width:30,height:30}} resizeMode={'contain'} source={require('../../assets/images/calendar_ellipse.png')}></Image>
                      <Text style={item.process=="due"?styles.propItemattrvalueError(theme):styles.propItemattrvalue(theme)}>INR {this.getMoneyFormat(item.amount,0)} due on {this.getDateFormat(item.paying_date)}</Text>
                    </View>
                    {item.process=="due"&&
                      <View style={styles.markwrap}>
                        <TouchableOpacity onPress={()=>this.PayRent()}>
                          <Text style={styles.marktext(theme)}>PAY NOW <Image style={styles.right_arrow} source={require('../../assets/images/right-arrow.png')}></Image></Text>
                        </TouchableOpacity>
                      </View>}
                  </View>
               </View>
            </ImageBackground>
          </ImageBackground>
        </View>
      )
    })
  }
  renderCollectingItems(){
    const {payingRent} = this.state
    return payingRent.map((item,inx)=>{
      return (
        <View key={inx} style={styles.loopitem}>
          <ImageBackground imageStyle={styles.loopitembgcltg} style={styles.loopitembgcltg} resizeMode={'stretch'} source={this.fasterImageRender(item)}>
            <ImageBackground imageStyle={styles.loopitembgcltgIn} style={styles.loopitembgcltgIn} resizeMode={'stretch'} source={require('../../assets/images/properties_item_bg.png')}>
               <Text style={styles.itemName(theme)}>{item.name}</Text>
               {item.process !="due" && <TouchableOpacity onPress={()=>this.ProPertyDetailLandlord()} style={styles.nextscreen(theme)}><Image style={styles.arrow_right} source={require('../../assets/images/arrow_right.png')}></Image></TouchableOpacity>}
               <View style={styles.propertygnInfo}>
                  <View style={styles.propInforowleft}>
                    {item.process=="due"?
                      <Image style={styles.due_label} source={require("../../assets/images/due_label.png")}></Image>
                    :null}
                  </View>
                  <View style={styles.propInforowright}>
                    <View style={styles.propInfoAttrb}>
                      <Image style={styles.map_icon} resizeMode={'contain'} source={require('../../assets/images/map_ellipse.png')}></Image>
                      <Text style={styles.propItemattrLocation(theme)}>{item.location}</Text>
                    </View>
                    <View style={styles.propInfoAttrb}>
                      <Image style={{width:30,height:30}} resizeMode={'contain'} source={require('../../assets/images/calendar_ellipse.png')}></Image>
                      <Text style={item.process=="due"?styles.propItemattrvalueError(theme):styles.propItemattrvalue(theme)}>INR {this.getMoneyFormat(item.amount,0)} due on {this.getDateFormat(item.paying_date)}</Text>
                    </View>
                    {item.process=="due"?
                      <View style={styles.markwrap}>
                        <TouchableOpacity>
                          <Text style={styles.marktext(theme)}>MARK AS PAID</Text>
                        </TouchableOpacity>
                      </View>
                    :null}
                  </View>
               </View>
            </ImageBackground>
          </ImageBackground>
        </View>
      )
    })
  }
  fasterImageRender(item){
    //console.log("loop itm in side fasterImageRender",item.image)
    if(!item.image || item.image==null || item.image==''){
      return require('../../assets/images/sample/sample_image_1.png');
    }
    return {uri:item.image};
  }
  renderCollectingPropertiest(){
    return(
      <View style={styles.properties(theme)}>
        {this.renderCollectingItems()}
      </View>
    )
  }

}
PropertiesTenants.navigationOptions = ({ navigation }) => ({
  headerStyle: {height:0},
  title: 'Properties/Tenants',
})

export default PropertiesTenants;
