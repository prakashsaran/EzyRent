import React from "react";
import { StyleSheet } from "react-native";
import { theme } from "../../../theme";
import {normalize} from '../../../components'

export default StyleSheet.create({
  container: theme => ({
    flex: 1,
    backgroundColor: theme.colors.primBackgroundColor,
  }),
  image: {
    width: 200,
    height: 200,
    marginTop: 50,
    alignSelf: "center",
  },
  stepTitle: theme => ({
    color: "#121212",
    fontSize: normalize(24),
    fontFamily: theme.typography.primaryFont,
    fontWeight:theme.typography.fontWeightBold,
    letterSpacing: 0,
    textAlign: "center",
    marginTop: 50,
    alignSelf: "center"
  }),
  signstep: theme => ({
    width: '100%',
    height: 20,
    color: theme.colors.descriptionColor,
    borderWidth: 0,
    fontSize: 14,
    fontFamily: theme.typography.secondaryFont,
    lineHeight: 20,
    letterSpacing: 0,
    marginVertical:theme.spacing.small,
    textAlign: "center",
  }),
  stepmessage: theme=> ({
    width: 309,
    height: 20,
    color: theme.colors.descriptionColor,
    borderWidth: 0,
    fontSize: 14,
    fontFamily: theme.typography.secondaryFont,
    lineHeight: 20,
    letterSpacing: 0,
    textAlign: "center",
    alignSelf: "center"
  }),
  mobileWrapper: theme=> ({
    width: '80%',
    alignSelf: "center",
    marginBottom:theme.spacing.large*2,
  }),
  pinwrapper: theme =>({
    flexDirection:'column',
    height:60,
    width:'80%',
    alignSelf:'center',
  }),

  pintitle: theme =>({
    fontFamily:theme.typography.primaryFont,
    fontWeight:theme.typography.fontWeightRegular,
    fontSize:16,
    color:theme.colors.descriptionColor,
  }),
  mobelTitle: theme =>({
    width: '80%',
    alignSelf: "center",
    color:theme.colors.secondry,
    marginTop:theme.spacing.extraLarge*2,
  }),
  mobileInput: theme=> ({
    borderBottomWidth:0.7,
    borderColor:theme.colors.secondry,
    fontSize: 18,
    fontFamily:theme.typography.primaryFont,
    fontWeight:theme.typography.fontWeightRegular,
    //marginTop:7,
    paddingBottom:2,
  }),

 btnProceedDisabled: theme =>({
    backgroundColor: theme.colors.disableBtnColor,
    width:'80%',
    opacity:0.7,
    flexDirection: "row",
    alignItems: "center",
    alignSelf:'center',
    justifyContent: "center",
    paddingRight: 16,
    paddingLeft: 16,
    elevation: 2,
    minWidth: 88,
    borderRadius: 5,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 5,
    marginTop:theme.spacing.extraLarge*2,

  }),

  btnProceed: theme =>({
    backgroundColor: theme.colors.secondry,
    width:'80%',
    flexDirection: "row",
    alignItems: "center",
    alignSelf:'center',
    justifyContent: "center",
    paddingRight: 16,
    paddingLeft: 16,
    elevation: 2,
    minWidth: 88,
    borderRadius: 5,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 5,
    marginTop:theme.spacing.extraLarge*2,
  }),
  caption: theme => ({
    color: theme.colors.primBtnTextColor,
    fontSize: 19,
    fontFamily: theme.typography.secondaryFont,
    fontWeight:theme.typography.fontWeightSemiBold,
    paddingVertical:theme.spacing.large,
  }),
  copyright: theme =>({
    width: '100%',
    textAlign:'center',
    marginTop: theme.spacing.extraLarge*3,
    marginBottom: theme.spacing.extraLarge*4,
    fontSize:14,
  }),
  signIn: theme =>({
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    marginTop:theme.spacing.large,
  }),

  cnfrmSignText: theme =>({
    fontSize:16,
    color:theme.colors.descriptionColor,
    fontFamily: theme.typography.secondaryFont,
}),
signLink: theme =>({
    fontSize:18,
    color:theme.colors.primary,
    paddingLeft:theme.spacing.tiny,
    fontFamily: theme.typography.primaryFont,
}),
pincontainer: theme => ({
  flexDirection:'row',
  justifyContent:'space-between',
  alignItems:'center',
  width:'100%',
  position:'relative',
}),
pininputBox: theme =>({
  height:40,
  width:'100%',
  alignSelf:'center',
}),

visibilityIcon:{
  width:30,
  height:25,
},
visibilityIconWrapp:{
  position:'absolute',
  right:0,
},
underlineStyleBase: theme => ({
  width: theme.dimens.defaultPinCodeWidth,
  height: 45,
  borderWidth: 0,
  borderBottomWidth: 1,
  color:theme.colors.descriptionColor,
  borderColor:theme.colors.descriptionColor,
  fontSize:22,
    fontFamily:theme.typography.primaryFont,
  fontWeight:theme.typography.fontWeightRegular,
}),
underlineStyleHighLighted: theme => ({
  borderColor: theme.colors.secondry,
}),

  footerImage: {
    position: 'absolute',
    width: '100%',
    bottom: 0,
    left:0,
    right:0,
    height: 75,
  }
});
