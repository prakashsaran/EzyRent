import { StyleSheet } from "react-native";
import { theme } from "../../../theme";

export default StyleSheet.create({
    container: {
      flex: 1,
    },
    titleWrapper:{
      width:'90%',
      alignSelf:'center',
      marginVertical:20,
      flexDirection:'row',
      justifyContent:'space-between',
      paddingTop:10,
    },
    myDashBoard: theme => ({
      color: theme.colors.secondry,
      fontSize: 24,
      textAlign: "left",
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      marginLeft:10,
    }),
    rectView: theme =>({
      backgroundColor:'#fff',
      flexDirection:'column',
      width:'100%',
      marginTop:theme.spacing.large,
      minHeight:theme.dimens.defaultScreenMinHeight,
      borderTopRightRadius: 35,
      borderTopLeftRadius: 35,
      paddingTop:0,
      paddingHorizontal:10,
    }),
    back_button:{
      width:30,
      height:17,
    },
    plus:{
      width:23,
      height:23,
      marginTop:-2,
    },
    textHeading: theme =>({
      color:theme.colors.secondry,
      fontSize:18,
      textTransform:'uppercase',
      fontWeight:'bold',
      paddingBottom:6,
    }),
    textSub: theme =>({
      color:theme.colors.secondry,
      fontSize:14,
      color:theme.colors.descriptionColor,
    }),
    gps_dark_icon:{
      width:18,
      height:18,
      marginTop:5,
    },
    ImageLeftWrap:{
      borderTopLeftRadius: 50,
      borderTopRightRadius: 50,
      borderBottomLeftRadius: 50,
      borderBottomRightRadius: 50,
      overflow:'hidden',
    },
    morelinksmall:{
      fontSize:14,
    },
    shadow:{
    backgroundColor: "#fff",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    elevation: 2,
    borderRadius: 2,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 3,
    borderRadius:10,
    marginVertical:5,
  },
    MoreLinkswrap:{
      width:'100%',
      //height:130,
      flexDirection:'row',
      padding:20,
      flexWrap:'wrap',
      //overflow:'hidden',
      borderRadius: 10,
      alignItems:'center',
      position:'relative',
      // zIndex:0,
    },
    More_icon:{
      width:3,
      height:30,
      marginTop:5,
    },
    MoreLinks:{
      paddingLeft:10,
    },
    MoreLinksItem: theme =>({
      color:'#000',
      fontSize:16,
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
    }),
    MoreLinksItemSub: theme =>({
      color:theme.colors.descriptionColor,
      fontSize:14,
      paddingLeft:7,
      paddingTop:2,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    AccountNo: theme =>({
      color:'#333',
      fontSize:16,
      paddingLeft:7,
      paddingTop:10,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    UserWrap:{
      paddingLeft:10,
    },
    contentWrap:{
      flexDirection:'row',
      paddingBottom:5,
    },
    User_image:{
      width:60,
      height:60,
      marginTop:5,
      marginRight:10,
    },
    heading_wrap:{
      flexDirection:'row',
    },
    UserWrap:{
      width:'71%',
      paddingLeft:10,
    },
    three_dots_light:{
      width:6,
      height:23,
    },
    hideShow:{
      //display:'none',
      position:'absolute',
      right:45,
      bottom:'-60%',
      backgroundColor: "#fff",
      borderRadius: 5,
      borderColor: "#e6e6e6",
      borderWidth: 1,
      shadowOffset: {
        height: 5,
        width: 5
      },
      shadowColor: "rgba(0,0,0,1)",
      shadowOpacity: 0.35,
      width:150,
      padding:10,
  },
    edit:{
      color:theme.colors.textValueColor,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      fontSize:18,
      marginVertical:5,
    },
    delete:{

    },
  });
