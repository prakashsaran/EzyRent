import React, { Component } from "react";
import { StyleSheet,StatusBar,ScrollView,TouchableOpacity, View,Image, Text, ImageBackground } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import NavigationService from '../../navigation/NavigationService';
import { ThemeContext, theme } from '../../theme';
import styles from './style';
import {
  NAVIGATION_ADD_PROPERTIES_TENANTS_VIEW_PATH,
} from '../../navigation/routes';

class myDashBoard extends React.Component {
  static contextType = ThemeContext;
  constructor(props){
    super();
    StatusBar.setBarStyle("light-content");
  }
  addPropertyTenant(){
    NavigationService.navigate(NAVIGATION_ADD_PROPERTIES_TENANTS_VIEW_PATH);
  }
  render(){
    const theme = this.context;
      return (
        <ImageBackground style={{width:'100%',height:'100%'}} resizeMode={'cover'} source={require('../../assets/images/dashboard_bg.png')}>
          <SafeAreaView style={styles.container}> 
              <ScrollView 
              showsVerticalScrollIndicator={false}
              >
                <View style={styles.titleWrapper}>
                  <Text style={styles.myDashBoard(theme)}>My DashBoard</Text>
                </View>
                <View style={styles.rectView(theme)}>
                <Text style={styles.quickLinks(theme)}>Quick Links</Text>

                <View style={styles.userinteraction}>
                  <TouchableOpacity style={styles.intcolums(theme)}>
                    <View style={styles.intcolumsInner}>
                      <Image style={styles.intIcons} source={require('../../assets/images/dashboard_my_profile.png')}></Image>
                      <Text style={styles.intcTitle(theme)}>My Profile</Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={()=>this.addPropertyTenant()} style={styles.intcolums(theme)}>
                    <View style={styles.intcolumsInner}>
                    <Image style={styles.intIcons} source={require('../../assets/images/dashboard_add_properties.png')}></Image>
                      <Text style={styles.intcTitle(theme)}>Add New Property/Tenant</Text>
                    </View>
                  </TouchableOpacity>
                </View>
                <View style={styles.accountstats(theme)}>
                  <Text style={styles.quickLinks(theme)}>Quick State</Text>
                  <Text style={styles.statsDesc(theme)}>A quick summary of your account on EzyRent </Text>
                  <View style={styles.statsdata(theme)}>
                    <View style={styles.dataItem(theme)}>
                      <Text style={styles.itemValue(theme)}>12</Text>
                      <Text style={styles.itemInfo(theme)}>Properties I am Collecting Rent</Text>
                    </View>
                    <View style={styles.dataItem(theme)}>
                      <Text style={styles.itemValue(theme)}>80K</Text>
                      <Text style={styles.itemInfo(theme)}>Total Rent I have to Receive</Text>
                    </View>
                    <View style={styles.dataItem(theme)}>
                      <Text style={styles.itemValue(theme)}>100%</Text>
                      <Text style={styles.itemInfo(theme)}>Consistency in Collecting Rent</Text>
                    </View>
                  </View>
                </View>
                <Image style={styles.databg(theme)} resizeMode={'stretch'} source={require('../../assets/images/dashboard_data_bg.png')}/>
                </View>
              </ScrollView>
          </SafeAreaView>
        </ImageBackground>
      );
  }
}
export default myDashBoard;
