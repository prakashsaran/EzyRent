import { StyleSheet } from "react-native";

export default StyleSheet.create({
  container: theme => ({
    flex: 1,
    backgroundColor: theme.colors.primBackgroundColor,
  }),
  image: {
    width: 200,
    height: 200,
    marginTop: 50,
    alignSelf: "center",
  },
  stepTitle: theme => ({
    color: "#121212",
    fontSize: 24,
    fontFamily: theme.typography.primaryFont,
    lineHeight: 24,
    letterSpacing: 0,
    textAlign: "center",
    marginTop: 50,
    alignSelf: "center"
  }),
  signstep: theme => ({
    width: '100%',
    height: 20,
    color: theme.colors.descriptionColor,
    borderWidth: 0,
    fontSize: 16,
    fontFamily: theme.typography.secondaryFont,
    lineHeight: 20,
    letterSpacing: 0,
    marginVertical:theme.spacing.small,
    textAlign: "center",
  }),
  stepmessage: theme=> ({
    width: 309,
    height: 20,
    color: theme.colors.descriptionColor,
    borderWidth: 0,
    fontSize: 16,
    fontFamily: theme.typography.secondaryFont,
    lineHeight: 20,
    letterSpacing: 0,
    textAlign: "center",
    alignSelf: "center"
  }),
  mobileWrapper: theme=> ({
    width: '80%',
    alignSelf: "center",
    marginVertical:theme.spacing.large,
  }),
  mobelTitle: theme =>({
    width: '80%',
    alignSelf: "center",
    color:theme.colors.secondry,
    marginTop:theme.spacing.extraLarge*2,
  }),
  mobileInput: theme=> ({
    borderBottomWidth:2,
    borderColor:theme.colors.secondry,
    fontSize: 22,
    fontFamily:theme.typography.primaryFont,
    fontWeight:theme.typography.fontWeightRegular,
    marginTop:7,
    paddingBottom:2,
  }),

 btnProceedDisabled: theme =>({
    backgroundColor: theme.colors.disableBtnColor,
    width:'80%',
    opacity:0.1,
    flexDirection: "row",
    alignItems: "center",
    alignSelf:'center',
    justifyContent: "center",
    paddingRight: 16,
    paddingLeft: 16,
    elevation: 2,
    minWidth: 88,
    borderRadius: 5,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 5,
    marginTop:theme.spacing.extraLarge*2,

  }),
 
  btnProceed: theme =>({
    backgroundColor: theme.colors.secondry,
    width:'80%',
    flexDirection: "row",
    alignItems: "center",
    alignSelf:'center',
    justifyContent: "center",
    paddingRight: 16,
    paddingLeft: 16,
    elevation: 2,
    minWidth: 88,
    borderRadius: 5,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 5,
    marginTop:theme.spacing.extraLarge*2,
  }),
  caption: theme => ({
    color: theme.colors.primBtnTextColor,
    fontSize: 24,
    fontFamily: theme.typography.secondaryFont,
    fontWeight:theme.typography.fontWeightSemiBold,
    paddingVertical:theme.spacing.medium,
  }),
  copyright: theme =>({
    width: '100%',
    textAlign:'center',
    marginTop: theme.spacing.extraLarge*3,
    marginBottom: theme.spacing.extraLarge*2,
  }),
  signIn: theme =>({
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    marginTop:theme.spacing.large,
  }),

  cnfrmSignText: theme =>({
    fontSize:16,
    color:theme.colors.descriptionColor,
    fontFamily: theme.typography.secondaryFont,
}),
signLink: theme =>({
    fontSize:18,
    color:theme.colors.primary,
    paddingLeft:theme.spacing.tiny,
    fontFamily: theme.typography.primaryFont,
}),

  footerImage: {
    position: 'absolute',
    width: '100%',
    bottom: 0,
    left:0,
    right:0,
    height: 75,
  }
});
