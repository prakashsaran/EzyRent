import React, { Component,useContext ,useState} from "react";
import {View, Image, Text,ScrollView,SafeAreaView,TouchableOpacity } from "react-native";
import styles from './style';
import { ThemeContext } from '../../../../theme';
import OTPInputView from '@twotalltotems/react-native-otp-input'
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import CountDown from 'react-native-countdown-component';
import { resendMailOtp } from '../../../../actions';
import {NAVIGATION_SIGN_UP_MAIL_ID_PATH,NAVIGATION_SIGN_UP_PROFILE_PATH} from '../../../../navigation/routes';
import NavigationService from '../../../../navigation/NavigationService';
import { DropDownHolder } from '../../../../components';

function SignUpMobile(props) {
const {email,otp} = props.mail;
const [enablebtn, setEnableButton] = useState(false);
const [resendEnable, setResendEnable] = useState(false);
const [resendtimeout, setResendTimeOut] = useState(120);
const [inputOtp, setInputOtp] = useState(null);

const theme = useContext(ThemeContext);
  const onCodeFilled = (code) =>{
    setEnableButton(true);
    setInputOtp(code);
  }
  const resendSubmit = (code) =>{
    setEnableButton(false);
    setResendEnable(false);
    setResendTimeOut(120);
    props.resendMailOtp(email);
  }

  const submitOtp = () =>{
    if (otp==inputOtp) {
      // DropDownHolder.alert('success', 'Successfull', 'Brand/Make has been saved successfully.')
      NavigationService.navigate(NAVIGATION_SIGN_UP_PROFILE_PATH)
    }else{
      DropDownHolder.alert('error', 'Error', 'Invalid OTP code.')
    }
  }

  return (
    <SafeAreaView style={styles.container(theme)}>
      <ScrollView>

        <Image
          source={require("../../../../assets/images/ezyrent_logo.png")}
          resizeMode="contain"
          style={styles.image}
        ></Image>

        <Text style={styles.stepTitle(theme)}>Create Your Account</Text>

        <Text style={styles.signstep(theme)}>STEP 4 OF 5</Text>
        <Text style={styles.stepmessage(theme)}>Just 2 more steps and you`re done. We hate paperwork too. Validate your email address</Text>

        <OTPInputView 
          pinCount={4} 
          style={styles.mobileWrapper(theme)}
          codeInputHighlightStyle={styles.underlineStyleHighLighted(theme)}
          autoFocusOnLoad
          onCodeFilled = {(code => {onCodeFilled(code)})}
          codeInputFieldStyle={styles.underlineStyleBase(theme)}
        />

        <TouchableOpacity disabled={!enablebtn} style={enablebtn?styles.btnProceed(theme):styles.btnProceedDisabled(theme)} onPress={()=>submitOtp()}>
          <Text style={styles.caption(theme)}>VALIDATE</Text>
        </TouchableOpacity>

        <View style={styles.signIn(theme)}>
          <Text style={styles.cnfrmSignText(theme)}>Haven`t received OTP?</Text>
          {!resendEnable && <Text style={styles.signLink(theme)}>Redend in</Text>}
          {resendEnable ?
            <TouchableOpacity onPress={()=>resendSubmit()}>
              <Text style={styles.signLink(theme)}>Resend</Text>
            </TouchableOpacity>
            :
            <CountDown
              size={12}
              until={resendtimeout}
              digitStyle={{backgroundColor: 'transprint'}}
              digitTxtStyle={styles.signLink(theme)}
              onFinish={() => {setResendTimeOut(120),setResendEnable(true)}}
              timeToShow={['M', 'S']}
              timeLabels={{m: null, s: null}}
              showSeparator
            />

          }
        </View>

        <TouchableOpacity style={styles.changeMobile(theme)} onPress={()=>{NavigationService.navigate(NAVIGATION_SIGN_UP_MAIL_ID_PATH)}}>
          <Text style={styles.changeMobileText(theme)}>Change email id</Text>
        </TouchableOpacity>

        <Text style={styles.copyright(theme)}>Copyright @ EzyRent 2020. All Rights Reserved</Text>

      </ScrollView>

        <Image
          source={require("../../../../assets/images/ezyrent-footer-icon.png")}
          resizeMode="repeat"
          style={styles.footerImage}
        ></Image>

    </SafeAreaView>
  );
}

const mapStateToProps = ({ signup }) => {
  const { error, success, loading,mail } = signup;

  return { error, success, loading,mail };
};

SignUpMobile.propTypes = {
  loading: PropTypes.bool,
  error: PropTypes.oneOfType(PropTypes.string, null),
  success: PropTypes.oneOfType(PropTypes.string, null),
  resendMailOtp: PropTypes.func.isRequired,
};

SignUpMobile.defaultProps = {
  error: null,
  success: null,
  loading: false,
};

export default connect(mapStateToProps, { resendMailOtp })(SignUpMobile);
