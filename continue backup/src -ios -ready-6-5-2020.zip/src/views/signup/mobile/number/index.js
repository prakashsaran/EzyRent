import React, { Component,useContext ,useState} from "react";
import {View, Image, Text,ScrollView,SafeAreaView,TouchableOpacity } from "react-native";
import styles from './style';
import { ThemeContext } from '../../../../theme';
import PhoneInput from 'react-native-phone-input'
import {NAVIGATION_SIGN_UP_MOBILE_OTP_PATH,NAVIGATION_SIGN_IN_MOBILE_NUMBER_PATH} from '../../../../navigation/routes';
import NavigationService from '../../../../navigation/NavigationService';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { signupMobile } from '../../../../actions';

function SignUpMobile(props) {
  const [dialcode, setDialCode] = useState('');
  const [mobilenumber, setMobileNumber] = useState('');
  const [enablebtn, setEnableButton] = useState(false);

const theme = useContext(ThemeContext);
  const onChangePhoneNumber = (number) =>{
    setMobileNumber(number);
    setEnableButton(phone.isValidNumber());
    setDialCode(phone.getDialCode());
  }
  const onSelectCountry = () =>{
    setEnableButton(phone.isValidNumber());
    setDialCode(phone.getDialCode());
  }
  const submit = () =>{
    props.signupMobile(mobilenumber,dialcode);
  }
  return (
    <SafeAreaView style={styles.container(theme)}>
      <ScrollView>

        <Image
          source={require("../../../../assets/images/ezyrent_logo.png")}
          resizeMode="contain"
          style={styles.image}
        ></Image>

        <Text style={styles.stepTitle(theme)}>Create Your Account</Text>

        <Text style={styles.signstep(theme)}>STEP 1 OF 5</Text>

        <Text style={styles.stepmessage(theme)}>Please enter your mobile number</Text>

        <Text style={styles.mobelTitle(theme)}>MOBILE</Text>

        <PhoneInput
          initialCountry={'in'}
          style={styles.mobileWrapper(theme)}
          textProps={{placeholder: 'Telephone number'}}
          offset={10}
          value={mobilenumber}
          textStyle={styles.mobileInput(theme)}
          ref={ref => {
            phone = ref;
          }}
          onChangePhoneNumber={(number) =>{onChangePhoneNumber(number)}}
          onSelectCountry={() =>{onSelectCountry()}}
        />

        <TouchableOpacity disabled={!enablebtn} style={enablebtn?styles.btnProceed(theme):styles.btnProceedDisabled(theme)}  onPress={()=>{submit()}}>
          <Text style={styles.caption(theme)}>PROCEED</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.signIn(theme)}  onPress={()=>{NavigationService.navigate(NAVIGATION_SIGN_IN_MOBILE_NUMBER_PATH)}} >
          <Text style={styles.cnfrmSignText(theme)}>Already have an account?</Text>
          <Text style={styles.signLink(theme)}>Sign In</Text>
        </TouchableOpacity>

        <Text style={styles.copyright(theme)}>Copyright @ EzyRent 2020. All Rights Reserved</Text>

      </ScrollView>

        <Image
          source={require("../../../../assets/images/ezyrent-footer-icon.png")}
          resizeMode="repeat"
          style={styles.footerImage}
        ></Image>

    </SafeAreaView>
  );
}

const mapStateToProps = ({ signup }) => {
  const { error, success, loading } = signup;

  return { error, success, loading };
};

SignUpMobile.propTypes = {
  loading: PropTypes.bool,
  error: PropTypes.oneOfType(PropTypes.string, null),
  success: PropTypes.oneOfType(PropTypes.string, null),
  signupMobile: PropTypes.func.isRequired,
};

SignUpMobile.defaultProps = {
  error: null,
  success: null,
  loading: false,
};

export default connect(mapStateToProps, { signupMobile })(SignUpMobile);
