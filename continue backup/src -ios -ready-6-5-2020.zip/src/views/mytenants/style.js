import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor:'#fff',
    },
    titleWrapper:{
      width:'90%',
      alignSelf:'center',
      marginVertical:20,
      flexDirection:'row',
      justifyContent:'space-between',
      paddingTop:10,
    },
    myDashBoard: theme => ({
      color: theme.colors.secondry,
      fontSize: 24,
      textAlign: "left",
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      marginLeft:10,
    }),
    rectView: theme =>({
      backgroundColor:'#fff',
      flexDirection:'column',
      width:'100%',
      marginTop:theme.spacing.large,
      minHeight:theme.dimens.defaultScreenMinHeight,
      borderTopRightRadius: 35,
      borderTopLeftRadius: 35,
      paddingTop:0,
      paddingHorizontal:10,
    }),
    back_button:{
      width:30,
      height:17,
    },
    three_dots:{
      width:6,
      height:23,
      marginTop:-6,
    },
    textHeading: theme =>({
      color:theme.colors.secondry,
      fontSize:18,
      textTransform:'uppercase',
      fontWeight:'bold',
      paddingBottom:6,
    }),
    textSub: theme =>({
      color:theme.colors.secondry,
      fontSize:14,
      color:theme.colors.descriptionColor,
    }),
    gps_dark_icon:{
      width:18,
      height:18,
      marginTop:5,
    },
    ImageLeftWrap:{
      borderTopLeftRadius: 50,
      borderTopRightRadius: 50,
      borderBottomLeftRadius: 50,
      borderBottomRightRadius: 50,
      overflow:'hidden',
    },
    morelinksmall:{
      fontSize:14,
    },
    shadow:{
      backgroundColor: "#fff",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      paddingRight: 16,
      paddingLeft: 16,
      elevation: 2,
      minWidth: 88,
      borderRadius: 2,
      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 5,
      marginVertical:5,
    },
    MoreLinkswrap:{
      width:'100%',
      //height:130,
      flexDirection:'row',
      padding:20,
      flexWrap:'wrap',
      overflow:'hidden',
      borderRadius: 10,
    },
    More_icon:{
      width:3,
      height:30,
      marginTop:5,
    },
    MoreLinks:{
      paddingLeft:10,
    },
    MoreLinksItem: theme =>({
      color:'#000',
      fontSize:16,
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
    }),
    MoreLinksItemSub: theme =>({
      color:theme.colors.descriptionColor,
      fontSize:16,
      paddingLeft:7,
      paddingTop:2,
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightLight,
    }),
    MoreLinksItemLocation: theme =>({
      color:theme.colors.descriptionColor,
      fontSize:16,
      paddingLeft:7,
      paddingTop:2,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    UserWrap:{
      paddingLeft:10,
    },
    contentWrap:{
      flexDirection:'row',
      paddingTop:10,
      paddingBottom:20,
    },
    User_image:{
      width:90,
      height:90,
      borderRadius:50,
    },
    heading_wrap:{
      flexDirection:'row',
    },
    UserWrap:{
      width:'71%',
      paddingLeft:10,
    },
  });
