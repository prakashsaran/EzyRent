import { StyleSheet } from "react-native";
import { theme } from "../../../theme";
import {isIphoneX} from "../../../components"
export default StyleSheet.create({
    container: theme => ({
      flex: 1,
      backgroundColor:theme.colors.secondry,
    }),
    headerContainer:theme=>({
      height:theme.dimens.headerWithBannerHeight,
    }),
 
    headerContext:{
      flexDirection:'row',
      justifyContent:'space-between',
      alignContent:'center',
      alignItems:'flex-start',
      padding:theme.spacing.large,
      height:theme.dimens.headerWithBannerHeight/2,
      //marginVertical:10,
      //marginHorizontal:20,
    },
    headerBanner:theme=>({
      backgroundColor:theme.colors.primBackgroundColor,
      padding:theme.spacing.large,
      width:'100%',
      height:theme.dimens.headerWithBannerHeight/2,
      //marginTop:theme.dimens.headerWithBannerHeight/4,
      position:'relative',
    }),
    headerBannerImage : theme =>({
      height:theme.dimens.headerWithBannerHeight-70,
      borderRadius:9,
      width:'100%',
      position:'absolute',
      alignSelf:'center',
      top:-(theme.dimens.headerWithBannerHeight/3)+25,

      ///
      alignItems: "center",
      justifyContent: "center",
      elevation: 2,
      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 9,
      backgroundColor:"#ffff",
    }),
   pageTitle: theme =>({
      color:theme.colors.primaryScreenTitle,
      fontSize:22,
      fontFamily:theme.typography.primaryFont,
      fontWeight: theme.typography.fontWeightRegular,
      marginLeft:15,
    }),
    backscreen:{
      width:35,
      height:35,
    },
    printscreen:{
      width:30,
      height:30,
    },
    formcontainer:{
      minHeight:theme.dimens.containerHeightWithBannerHeader,
      height:theme.dimens.containerHeightWithBannerHeader,
      backgroundColor:theme.colors.primBackgroundColor,
      paddingBottom:100,
    },
    formColumnWrapp:{
      padding:20,
      width:'100%',
      alignItems:'center',
      flexDirection:'column',
    },
    fieldWrapp:{
      width:'100%',
      marginTop:20,
      borderWidth:1,
      borderColor:'transparent',
    },
    tooltip:theme=>({
      color:theme.colors.descriptionColor,
      fontFamily:theme.typography.secondryFont,
      fontSize:16,
      fontWeight:theme.typography.fontWeightRegular,
      width:'100%',
      textAlign:'left',
    }),
    responseValue:theme =>({
      width:'100%',
      borderColor:theme.colors.secondry,
      borderBottomWidth:1,
      color:theme.colors.primaryTitleColor,
      fontFamily:theme.typography.secondryFont,
      fontSize:22,
      fontWeight:theme.typography.fontWeightRegular,
      marginVertical:theme.spacing.medium,
    }),

    itemName:theme =>({
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      fontSize:20,
      width:'80%',
      alignSelf:'center',
      color:theme.colors.secondry,
      marginTop:theme.spacing.large,
      paddingLeft:20,
      alignSelf:'flex-end',
    }),
    propItemattrLocation: theme=>({
      color:theme.colors.descriptionColor,
      paddingHorizontal:5,
      fontSize:18,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      paddingVertical:2,
    }),
    statusTextValue: theme=>({
      color:theme.colors.primary,
      paddingHorizontal:1,
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    loopitembg:{
      width:'100%',
      height:200,
      borderRadius:9
    },
    propertygnInfo:{
      width:'100%',
      flexDirection:'row',
      justifyContent:'flex-end',
      paddingVertical:10,
    },
    propInfoAttrb:{
      flexDirection:'row',
      justifyContent:'space-between',
      alignItems:'center',
      paddingVertical:5,
     // flexWrap:'wrap',
    },
    locationWrapp:{
      width:'65%',
      alignSelf:'flex-end',
    },
    transactionInf:{    
      flexDirection: "column",
      width:'100%',
      alignItems: "center",
      justifyContent: "center",
      paddingRight: 16,
      paddingLeft: 16,
      elevation: 2,
      minWidth: 88,
      borderRadius: 2,
      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 5,
      backgroundColor:"#ffff",
      paddingVertical:30,
      marginBottom:20,
    },
    columntitle:theme=>({
      color:theme.colors.descriptionColor,
      fontFamily:theme.typography.primaryFont,
      fontSize:20,
      fontWeight:theme.typography.fontWeightRegular,
      width:'100%',
      textAlign:'left',
    }),

    
});