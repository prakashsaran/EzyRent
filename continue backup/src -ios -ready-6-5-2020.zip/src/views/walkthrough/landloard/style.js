import {
  StyleSheet,
} from "react-native";

export default StyleSheet.create({
  container: theme => ({
  	flex: 1,
    backgroundColor:theme.colors.primBackgroundColor,
  }),
  skipwalkthrough:{
    alignItems:'flex-start',
    padding:10,
  },
  skipText: theme => ({
    color: theme.colors.primary,
    fontSize: 24,
    marginLeft: 15,
    fontFamily:theme.typography.secondaryFont,
    fontStyle:'normal',
    fontWeight:theme.typography.fontWeightSemiBold,
  }),
  landloardimage:{
    width:'80%',
    height:370,
    alignSelf:'center',
  },
  itemcontainer:{
    flexDirection:'column',
  },
  landlordProperties: theme =>({
    color:theme.colors.secondry,
    textAlign:'center',
    fontSize:26,
    paddingHorizontal:10,
    fontWeight:theme.typography.fontWeightBold,
    fontFamily:theme.typography.primaryFont,
  }),
  pageInfo: theme =>({
    color:theme.colors.descriptionColor,
    textAlign:'center',
    fontSize:18,
    marginVertical:10,
    paddingHorizontal:10,
    fontWeight:theme.typography.fontWeightRegular,
    fontFamily:theme.typography.secondaryFont,
    marginTop:theme.spacing.small,
  }),
  btncontainer: theme =>({
    backgroundColor: theme.colors.secondry,
    width:'80%',
    flexDirection: "row",
    alignItems: "center",
    alignSelf:'center',
    justifyContent: "center",
    paddingRight: 16,
    paddingLeft: 16,
    elevation: 2,
    minWidth: 88,
    borderRadius: 5,
    shadowOffset: {
      height: 1,
      width: 0
    },
    shadowColor: "#000",
    shadowOpacity: 0.35,
    shadowRadius: 5,
    marginTop:theme.spacing.extraLarge,
  }),
  caption: theme =>({
    color: theme.colors.primBtnTextColor,
    fontSize: 24,
    fontFamily: theme.typography.secondaryFont,
    fontWeight:theme.typography.fontWeightSemiBold,
    paddingVertical:theme.spacing.medium,
  }),
  walkIndicator:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    marginVertical:20,
    width:50,
    alignSelf:'center',

  }

});
