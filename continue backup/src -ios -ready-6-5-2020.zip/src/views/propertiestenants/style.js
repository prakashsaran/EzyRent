import { StyleSheet } from "react-native";
import { theme } from "../../theme";

export default StyleSheet.create({
    container: theme => ({
      flex: 1,
      backgroundColor:theme.colors.primBackgroundColor,
    }),
    headWrapp:{
      flexDirection:'column',
      paddingHorizontal:10,
    },
    headcontainer: {
      backgroundColor: "#ffffff",
      flexDirection: "row",
      alignItems: "center",
      padding: 4,
      justifyContent:'space-between',
      alignContent:'center',
      alignItems:'center',
    },
    title: theme =>({
      backgroundColor: "transparent",
      color: theme.colors.secondry,
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      fontSize: 22,
    }),
    rightIconsWrapper: {
      flexDirection: "row",
      alignItems: "center",
      marginRight: 5,
      marginTop: 5
    },
    headerIcon:{
      width:30,
      height:30,
    },
    searchClear:{
      width:20,
      height:20,
    },
    iconButton: {
      marginLeft: 5,
    },
    iconButton2: {
      marginLeft: 30,
    },
    searchWrap: {
      width:'100%',
      alignItems:'center',
      elevation: 3,
      shadowOffset: {
        height: 2,
        width: 0
      },
      shadowColor: "#111",
      shadowOpacity: 0.2,
      shadowRadius: 1.2,
      marginTop:10,
    },
    inputStyleStack:theme=> ({
      flexDirection:'row',
      width: '100%',
      height: 48,
      borderWidth:0.5,
      borderColor:theme.colors.secondry,
      padding:5,
    }),
    searchinputStyle:{
      width:'100%',
    },
    searchRightIcon:{
      position:'absolute',
      right:10,
      top:10,
    },
    tabWrapp:{
      width:'100%',
    },
    tabtitle:theme =>({
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      fontSize:22,
      paddingHorizontal:10,
    }),
    inActivetabtitle:theme =>({
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      fontSize:22,
      paddingHorizontal:10,
      color:theme.colors.seconderyHeadingColor,
    }),
    Activetabtitle:theme =>({
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      fontSize:22,
      paddingHorizontal:10,
      color:theme.colors.secondry,
    }),
    tabsrows:{
      marginTop:20,
      flexDirection:'row',
      justifyContent:'space-between',
    },
    inActivetabitem: theme=>({
      paddingBottom:4,
    }),
    Activetabitem: theme=>({
      paddingBottom:4,
      borderBottomWidth:2,
      borderColor:theme.colors.secondry,
    }),
    properties:theme =>({
      backgroundColor:theme.colors.thirdBackgrounColor,
      width:'100%',
      padding:10,
    }),
    loopitem:{
      paddingVertical:4,
      borderRadius:9,
    },
    loopitembg:{
      width:'100%',
      height:200,
      borderRadius:9
    },
    loopitembgcltg:{
      width:'100%',
      height:220,
      borderRadius:9
    },
    itemName:theme =>({
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      fontSize:18,
      width:'50%',
      alignSelf:'center',
      color:theme.colors.primaryTitleColor,
      marginTop:theme.spacing.large,
      paddingLeft:20,
    }),
    propertygnInfo:{
      width:'100%',
      flexDirection:'row',
      justifyContent:'space-between',
      paddingVertical:10,
    },
    propInforowleft:{
      width:'38%',
      flexDirection:'column',
    },
    propInforowright:{
      width:'62%',
      flexDirection:'column',
    },
    propInfoAttrb:{
      flexDirection:'row',
      justifyContent:'space-between',
      alignItems:'center',
      paddingVertical:5,
     // flexWrap:'wrap',
    },
    propItemattrLocation: theme=>({
      color:theme.colors.primaryTitleColor,
      paddingHorizontal:5,
      flexWrap:'wrap',
      width:'88%',
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    propItemattrvalue: theme=>({
      color:theme.colors.primary,
      paddingHorizontal:5,
      flexWrap:'wrap',
      width:'88%',
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    propItemattrvalueError: theme=>({
      color:theme.colors.errorColor,
      paddingHorizontal:5,
      flexWrap:'wrap',
      width:'88%',
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    markwrap:{alignItems:'flex-end',width:'50%',alignSelf:'flex-end',marginRight:20,},
    marktext:theme =>({
      color:theme.colors.secondry,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      fontSize:16,
    }),
    nextscreen:theme=>({
      position:'absolute',
      top:theme.spacing.large,
      right:20,
    })
  });
