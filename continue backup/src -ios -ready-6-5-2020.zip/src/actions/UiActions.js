import _ from 'lodash';
const emailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
const nameRegex = /^[a-zA-Z]+ [a-zA-Z]+$/;

export const isValidEmail = (email) => {
    return emailRegex.test(email);
}
export const isValidName = (name) => {
    return nameRegex.test(name);
}
  