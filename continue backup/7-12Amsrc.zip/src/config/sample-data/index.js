import { find, orderBy } from 'lodash';
let instance = null;

class SampleData {
constructor(){
    this.propertiesData = null;
}
  static getInstance() {
    if (!instance) {
      instance = new SampleData();
    }
    return instance;
  }
  getPropeties(){
    if (!this.properties) {
      this.properties = orderBy(
        this.propertiesData || require('./properties.json'),
        ['name'],
        ['asc'],
      );
    }

    return this.properties;
  }

  getNotifications(){
    if (!this.notifications) {
      this.notifications = orderBy(
        this.notifications || require('./notifications.json'),
        ['name'],
        ['asc'],
      );
    }

    return this.notifications;
  }


  getPayingRent(){
      return this.getPropeties();
  }
  getcollectingRent(){
      return this.getPropeties();
  }
}
export default SampleData.getInstance();
