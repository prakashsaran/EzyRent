import { StyleSheet } from "react-native";
import { theme } from "../../../theme";

export default StyleSheet.create({
    container: {
      flex: 1,
    },
    titleWrapper:{
      width:'90%',
      alignSelf:'center',
      marginVertical:20,
      flexDirection:'row',
    },
    myDashBoard: theme => ({
      color: theme.colors.primaryScreenTitle,
      fontSize: 22,
      textAlign: "left",
      fontFamily:theme.typography.primaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      paddingLeft:10,
    }),
    rectWrapp:{
      backgroundColor:theme.colors.lightBackgrountColor,
      marginTop:80,
      minHeight:theme.dimens.defaultScreenMinHeight,
    },
    rectView: theme =>({
      backgroundColor:theme.colors.primBackgroundColor,
      flexDirection:'column',
      width:'95%',
      alignSelf:'center',
      marginTop:theme.spacing.large,
      borderRadius: 15,
      paddingTop:30,
      marginTop:-80,
      paddingHorizontal:40,

      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 5,
      backgroundColor:"#ffff",
      paddingVertical:30,
      marginBottom:20,

    }),
    backscreen:{
      width:35,
      height:35,
    },
    columntitle:theme=>({
      color:theme.colors.descriptionColor,
      fontFamily:theme.typography.secondryFont,
      fontSize:20,
      fontWeight:theme.typography.fontWeightBold,
      width:'100%',
      textAlign:'left',
    }),
    tooltip:theme=>({
      color:theme.colors.secondry,
      fontFamily:theme.typography.secondryFont,
      fontSize:16,
      fontWeight:theme.typography.fontWeightRegular,
      width:'100%',
      textAlign:'left',
      marginBottom:10,
    }),
    fieldWrapp:{
      width:'100%',
      marginTop:20,
      borderWidth:1,
      borderColor:'transparent',
    },
    textInputStyle:theme=>({
      width:'100%',
      borderColor:theme.colors.secondry,
      borderBottomWidth:1,
      color:theme.colors.primaryTitleColor,
      fontFamily:theme.typography.secondryFont,
      fontSize:18,
      fontWeight:theme.typography.fontWeightRegular,
      marginTop:theme.spacing.small,
    }),
    textInputStyleSec:theme=>({
      width:'100%',
      borderColor:theme.colors.descriptionColor,
      borderBottomWidth:1,
      color:theme.colors.primaryTitleColor,
      fontFamily:theme.typography.secondryFont,
      fontSize:16,
      fontWeight:theme.typography.fontWeightRegular,
      marginTop:theme.spacing.small,
    }),
    addBtncontainer:theme=>({
      position: 'absolute',
      flex: 1,
      left: 0,
      right: 0,
      bottom: 0,
      width:'100%',
      backgroundColor:theme.colors.secondry,
      alignItems:'center',
      justifyContent:'center',
      height:50,
    }),
    addBtncaption:theme =>({
      //borderBottomWidth:1,
      color:theme.colors.primBtnTextColor,
      fontFamily:theme.typography.primaryFont,
      fontSize:22,
      fontWeight:theme.typography.fontWeightSemiBold,
    }),
    spacing:{
      width:'100%',
      height:20,
      paddingBottom:20,
    },

  });
