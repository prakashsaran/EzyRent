export default {
  /**
   * ========================= Primary color : =========================
   */
  primary:'rgba(70,180,21,1)',
  secondry: '#3059DD',
  descriptionColor: '#484848',
  primBtnTextColor: '#FFFFFF',
  primBackgroundColor: '#FFFFFF',
  primaryTitleColor:'#000000',
  disableBtnColor:'#494949',
  headingColor:"#121212",
  primaryScreenTitle:'#FFFFFF',
  secondryBackgrounColor:'#f4f7fe',
  seconderyHeadingColor:'#818181',
  thirdBackgrounColor:'#e8e8e8',
  errorColor:'#ef4c4d',
  textValueColor:'#333333',
  lightBackgrountColor:'#f7f7f7',
};
