import { Platform } from 'react-native';
import colors from './colors';

const fontFamilyMontserrat = 'Montserrat';
const fontFamilyOxygen = 'Oxygen';
const fontWeightRegular = 'normal';
const fontWeightSemiBold = '600';
const fontWeightMedium = '500';
const fontWeightLight = '300';
const fontWeightBold = 'bold';

const titleTextColor = colors.primaryDark;

export default {
  /**
   * Title is reserved for the title of a screen(Toolbar)
   * and the titles of Modal dialogs.
   */
  titleText: {
    fontFamily:fontFamilyMontserrat,
    color: titleTextColor,
    fontSize: 18,
    fontStyle: 'normal',
    fontWeight: fontWeightRegular,
  },
  primaryFont:fontFamilyMontserrat,
  secondaryFont:fontFamilyOxygen,
  fontWeightSemiBold:fontWeightSemiBold,
  fontWeightBold:fontWeightBold,
  fontWeightRegular,
  fontWeightLight,
  fontWeightMedium,
};
