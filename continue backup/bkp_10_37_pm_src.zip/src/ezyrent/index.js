import _ from 'lodash';
const defaultOptions = {
  url: null,
  userAgent: 'ios, mobile, apple ',
  authentication: {
    integration: {
      access_token: undefined,
    },
  },
};

class EzyRentClass {
	setOptions(options) {
	    this.configuration = { ...defaultOptions, ...options };
	    this.base_url = this.configuration.url;
	}

	init() {
	  console.log("initially execute function init class EzyRent ")
	}
}
export const EzyRent = new EzyRentClass();
