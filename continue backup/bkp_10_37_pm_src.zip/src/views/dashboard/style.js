import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
    },
    titleWrapper:{
      width:'90%',
      alignSelf:'center',
      marginVertical:20,
      flexDirection:'column',
    },
    myDashBoard: theme => ({
      color: theme.colors.primaryScreenTitle,
      fontSize: 24,
      textAlign: "left",
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
    }),
    rectView: theme =>({
      backgroundColor:theme.colors.secondryBackgrounColor,
      flexDirection:'column',
      width:'100%',
      marginTop:theme.spacing.large,
      //minHeight:theme.dimens.defaultScreenMinHeight,
      borderTopRightRadius: 35,
      borderTopLeftRadius: 35,
      paddingTop:30,
      paddingHorizontal:10,
    }),
    quickLinks:theme=>({
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightSemiBold,
      color:theme.colors.primaryTitleColor,
    }),
    userinteraction:{
      flexDirection:'row',
      justifyContent:'space-between',
      marginVertical:20,
    },
    intcolums: theme =>({
      width:'48%',
      borderRadius: 10,
      backgroundColor:theme.colors.primBtnTextColor,
      alignItems:'center',
      paddingVertical:20,
      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 5,
    }),
    intIcons:{
      width:40,
      height:40,
    },
    intcolumsInner:{
      width:'100%',
      alignItems:'center',
    },
    intcTitle:theme=>({
      fontSize:14,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      marginTop:10,
      paddingHorizontal:4,
    }),
    accountstats:theme=>({
      width:'98%',
      alignSelf:'center',
      shadowOffset: {
        height: 1,
        width: 0
      },
      shadowColor: "#000",
      shadowOpacity: 0.35,
      shadowRadius: 5,
      borderRadius: 10,
      backgroundColor:theme.colors.primBtnTextColor,
      paddingHorizontal:10,
      paddingVertical:10,
    }),
    statsDesc: theme =>({
      color:theme.colors.descriptionColor,
      fontSize:16,
      fontFamily:theme.typography.secondaryFont,
      fontWeight:theme.typography.fontWeightRegular,
      marginVertical:10,
    }),
    statsdata:theme=>({
      flexDirection:'row',
      justifyContent:'space-between',
    }),
    dataItem: theme =>({
      width:'32%',
      alignItems:'center',
    }),
    itemValue: theme =>({
      fontWeight:theme.typography.fontWeightSemiBold,
      fontFamily:theme.typography.primaryFont,
      color:theme.colors.secondry,
      fontSize:22,
    }),
    itemInfo: theme =>({
      fontWeight:theme.typography.fontWeightRegular,
      fontFamily:theme.typography.secondaryFont,
      color:theme.colors.primaryTitleColor,
      fontSize:14,
      width:'100%',
      textAlign:'center',
      paddingHorizontal:2,
      marginVertical:5,
    }),
    databg: theme =>({
      width:'70%',
      alignSelf:'center',
      height:120,
      marginTop:70,
    })
  });
