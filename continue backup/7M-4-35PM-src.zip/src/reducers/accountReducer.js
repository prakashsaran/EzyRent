import {
  EZYRENT_AUTHENTICATION_LOADING,
  EZYRENT_SIGN_UP_SUCCESS,
} from '../actions/types';

const INITIAL_STATE = {
  customer: null,
  refreshing: false,
  error: "",
  success: "",
  loading: false,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case EZYRENT_SIGN_UP_SUCCESS: {
      return {...state,customer: action.payload,};
    }
    case EZYRENT_AUTHENTICATION_LOADING: {
      return {...state,loading: action.payload,};
    }
    default:
      return state;
  }
};
