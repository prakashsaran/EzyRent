import {  AsyncStorage } from 'react-native';
//import AsyncStorage from '@react-native-community/async-storage';
import { EzyRent } from '../ezyrent';
import SampleData from '../config/sample-data'
import {
  EZYRENT_SIGN_UP_ACCOUNT,
  EZYRENT_SIGN_IN_ACCOUNT,
  EZYRENT_AUTHENTICATION_LOADING,
  EZYRENT_AUTHENTICATION_ERROR,
  EZYRENT_SIGN_UP_MOBILE_NUMBER,
  EZYRENT_SIGN_UP_EMAIL_ID,
  EZYRENT_SIGN_IN_MOBILE_NUMBER,
  EZYRENT_SIGN_IN_EMAIL_ID,
  EZYRENT_SIGN_IN_SUCCESS,
} from './types';
import NavigationService from '../navigation/NavigationService';
import {
  NAVIGATION_SIGN_UP_MOBILE_OTP_PATH,
  NAVIGATION_SIGN_UP_MAIL_OTP_PATH,
  SWITCH_NAVIGATION_AUTHORIZED_ACCOUNT_PATH,
  NAVIGATION_SIGN_IN_MOBILE_OTP_PATH,
  NAVIGATION_SIGN_UP_MAIL_ID_PATH,
  NAVIGATION_SIGN_IN_MAIL_OTP_PATH,
  NAVIGATION_SIGN_UP_PROFILE_PATH,
} from '../navigation/routes';

export const signIn = customer => async (dispatch) => {
	dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
	try {
    //signin proccess
    const allAccounts = SampleData.getAccounts() || [];
    let currentAc = undefined;
    if(customer.hasOwnProperty("number")){
      currentAc = allAccounts.find(objct => objct.contact==customer.number);
    } else if(customer.hasOwnProperty("email")){
      currentAc = allAccounts.find(objct => objct.email==customer.email);
    }
    if(!currentAc){
      currentAc = SampleData.getFreshAccount();
    }
    EzyRent.setCurrentAccount(currentAc);
    NavigationService.navigate(SWITCH_NAVIGATION_AUTHORIZED_ACCOUNT_PATH);
		dispatch({ type: EZYRENT_SIGN_IN_SUCCESS, payload: currentAc });
	} catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};


export const signUp = customer => async (dispatch) => {
	dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
	try {
    //signup proccess
    NavigationService.navigate(SWITCH_NAVIGATION_AUTHORIZED_ACCOUNT_PATH);
    let currentAc = SampleData.getFreshAccount();
    EzyRent.setCurrentAccount(currentAc);
		dispatch({ type: EZYRENT_SIGN_UP_ACCOUNT, payload: currentAc });
	} catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};


// setup account at EzyRent

/**
 * @description signupMobile method : create a new account at EzyRent
 * @param mobile string
 * @param dialcode string
 * @returns avoid,
 * @callback NavigationService.navigate();
 **/
export const signupMobile = (mobilenumber,dialcode='0091') => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess
    // form data
    const data = {
      "mobile_country_code": dialcode,
      "mobile": mobilenumber,
    }
    // form data convert to application/x-www-form-urlencoded
    const formData = formUrlencodedData(data);
    // response otp from sms server
    const response = await EzyRent.guest.setupMobile(formData);
    console.log("signupMobile response",response)
    if(response && response.data){
      const dataToProps = {id:response.data.id,status:response.data.status,number:mobilenumber,dialcode:dialcode,otp:null}
       dispatch({ type: EZYRENT_SIGN_UP_MOBILE_NUMBER, payload: dataToProps });
      if(response.data.status=='N'){
        NavigationService.navigate(NAVIGATION_SIGN_UP_MOBILE_OTP_PATH);  
      } else if(response.data.status=='M'){
        NavigationService.navigate(NAVIGATION_SIGN_UP_MAIL_ID_PATH);  
      }
  }
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};

/**
 * @description resendMobileOtp method : resend Otp at create account
 * @param mobilenumber object
 * @param type string
 * @returns avoid
 * @callback NavigationService.navigate();
 **/
export const resendMobileOtp = (mobilenumber,type) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    console.log("mobilenumber ===",mobilenumber);
    // send otp proccess
      // form data
      const data = {
        "id": mobilenumber.id,
        "type": type,
      }
      // form data convert to application/x-www-form-urlencoded
      const formData = formUrlencodedData(data);

    // response otp from sms server
    const response = await EzyRent.guest.setupResendMobileOtp(formData);
    
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};

/**
 * @description resendMobileOtp method : resend Otp at create accoutn
 * @param mobile string
 * @param dialcode string
 * @returns avoid
 * @callback NavigationService.navigate();
 **/
export const signupMobileOtp = (mobiledata,mobile_otp) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess
    // user id
    const userId = mobiledata.id;

    // form data
    const data = {mobile_otp}

    // form data convert to application/x-www-form-urlencoded
    const formData = formUrlencodedData(data);
    console.log("pre entry data",mobiledata)
    const response = await EzyRent.guest.setupMobileOtp(userId,formData);
    if(response){
      mobiledata.status =response.data.status;
      mobiledata.otp =response.data.mobile_otp;
      dispatch({ type: EZYRENT_SIGN_UP_MOBILE_NUMBER, payload: mobiledata });
      NavigationService.navigate(NAVIGATION_SIGN_UP_MAIL_ID_PATH);  
    }

    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }

}

/**
 * @description signupMail method : send mail to verification valid email address
 * @param mobiledata object
 * @param email string
 * @returns avoid
 * @callback NavigationService.navigate();
 **/
export const signupMail = (mobiledata,email) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess

    //form data
    const data = {"id":mobiledata.id,"email":email}

    // form data convert to application/x-www-form-urlencoded
    const formData = formUrlencodedData(data);

    // response otp from sms server
    const response = await EzyRent.guest.setupEmail(formData);
    console.log("response signupMail",response)
    if(response){
      dispatch({ type: EZYRENT_SIGN_UP_EMAIL_ID, payload: {email:email} });
     NavigationService.navigate(NAVIGATION_SIGN_UP_MAIL_OTP_PATH);
  }

    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};


/**
 * @description signupMailOtp method :  verification  email otp
 * @param mobiledata object
 * @param email_otp string
 * @returns avoid
 * @callback NavigationService.navigate();
 **/
export const signupMailOtp = (mobiledata,email_otp) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    console.log("mobiledata signupMailOtp =>",mobiledata);
    //NavigationService.navigate(NAVIGATION_SIGN_UP_PROFILE_PATH)
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
}

const formUrlencodedData = (data)=>{
  var formBody = [];
  for (var item in data) {
    formBody.push(item + "=" + data[item]);
  }
  formBody = formBody.join("&");
  return formBody;
}

export const signinMail = (email) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess
    // response otp from sms server
    let otp = 1234;
    dispatch({ type: EZYRENT_SIGN_IN_EMAIL_ID, payload: {email:email,otp:otp} });
    NavigationService.navigate(NAVIGATION_SIGN_IN_MAIL_OTP_PATH);
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};


export const signinMobile = (mobilenumber,dialcode=null) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess
    // response otp from sms server
    let responseOtp = 1234;
    dispatch({ type: EZYRENT_SIGN_IN_MOBILE_NUMBER, payload: {number:mobilenumber,dialcode:dialcode,otp:responseOtp} });
    NavigationService.navigate(NAVIGATION_SIGN_IN_MOBILE_OTP_PATH);
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};





export const resendMailOtp = (email) => async (dispatch) => {
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: true });
  try {
    // send otp proccess
    // response otp from sms server
    let responseOtp = 1234;
    dispatch({ type: EZYRENT_SIGN_UP_EMAIL_ID, payload: {email:email,otp:responseOtp} });
    dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
  } catch (e) {
    console.error(e)
    authFail(dispatch, e.message);
  }
};

const authFail = (dispatch, message) => {
  dispatch(errorMessage(message));
  dispatch({ type: EZYRENT_AUTHENTICATION_LOADING, payload: false });
};
export const errorMessage = error => ({ type: EZYRENT_AUTHENTICATION_ERROR, payload: error });
