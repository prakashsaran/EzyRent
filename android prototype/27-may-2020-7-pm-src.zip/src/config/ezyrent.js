export const ezyrentOptions = {
  url: 'https://ezyrent.com/',
  authentication: {
    integration: {
      access_token: 'xyz_token_number',
    },
  },
};

